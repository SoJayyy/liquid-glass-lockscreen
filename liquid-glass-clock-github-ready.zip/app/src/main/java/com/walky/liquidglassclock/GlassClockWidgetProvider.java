package com.walky.liquidglassclock;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

public class GlassClockWidgetProvider extends AppWidgetProvider {
    static void updateWidget(Context context, AppWidgetManager manager, int id) {
        int theme = context.getSharedPreferences("clock_settings", Context.MODE_PRIVATE)
                .getInt("theme", 0);
        int[] backgrounds = {R.drawable.glass_silver, R.drawable.glass_champagne,
                R.drawable.glass_blue, R.drawable.glass_rose};
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_glass_clock);
        views.setInt(R.id.glass_panel, "setBackgroundResource", backgrounds[Math.max(0, Math.min(3, theme))]);
        manager.updateAppWidget(id, views);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateWidget(context, manager, id);
    }

    @Override public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                                     int id, android.os.Bundle options) {
        updateWidget(context, manager, id);
    }
}
