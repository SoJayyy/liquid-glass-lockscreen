package com.walky.liquidglassclock;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String PREFS = "clock_settings";
    private static final String THEME = "theme";
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF090D16);
        getWindow().setNavigationBarColor(0xFF090D16);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24));
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setBackgroundColor(0xFF090D16);

        TextView title = new TextView(this);
        title.setText("LIQUID GLASS");
        title.setTextColor(0xFFEAF1FA);
        title.setTextSize(13);
        title.setLetterSpacing(0.18f);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(32)));

        TextView subtitle = new TextView(this);
        subtitle.setText("CLOCK WIDGET  ·  24 JAM");
        subtitle.setTextColor(0xFF9BA9BA);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(28)));

        View gap = new View(this);
        page.addView(gap, new LinearLayout.LayoutParams(1, dp(26)));

        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setGravity(Gravity.CENTER);
        preview.setPadding(dp(18), dp(22), dp(18), dp(22));
        preview.setBackgroundResource(R.drawable.glass_silver);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(0xFFF5F8FC);
        clock.setTextSize(62);
        clock.setGravity(Gravity.CENTER);
        clock.setTypeface(android.graphics.Typeface.create("sans-serif-light", 0));
        preview.addView(clock, new LinearLayout.LayoutParams(-1, dp(82)));
        TextClock date = new TextClock(this);
        date.setFormat24Hour("EEEE, d MMMM");
        date.setFormat12Hour("EEEE, d MMMM");
        date.setTextColor(0xFFD7E0EA);
        date.setTextSize(14);
        date.setGravity(Gravity.CENTER);
        preview.addView(date, new LinearLayout.LayoutParams(-1, dp(30)));
        page.addView(preview, new LinearLayout.LayoutParams(-1, dp(160)));

        TextView choose = new TextView(this);
        choose.setText("PILIH TEMA KACA");
        choose.setTextColor(0xFFB8C4D3);
        choose.setTextSize(12);
        choose.setLetterSpacing(0.12f);
        choose.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(-1, dp(52));
        chooseLp.topMargin = dp(18);
        page.addView(choose, chooseLp);

        String[] names = {"Silver", "Champagne", "Cool Blue", "Rose Gold"};
        int[] drawables = {R.drawable.glass_silver, R.drawable.glass_champagne,
                R.drawable.glass_blue, R.drawable.glass_rose};
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            final int selected = i;
            Button b = new Button(this);
            b.setText(names[i]);
            b.setTextSize(10);
            b.setAllCaps(false);
            b.setOnClickListener(v -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(THEME, selected).apply();
                preview.setBackgroundResource(drawables[selected]);
                updateWidgets();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1);
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(b, lp);
        }
        page.addView(row, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView instructions = new TextView(this);
        instructions.setText("CARA MEMASANG WIDGET\\n\\n1. Kembali ke layar utama.\\n2. Tekan lama area kosong.\\n3. Pilih Widget > Liquid Glass Clock.\\n4. Tarik widget ke posisi yang diinginkan.\\n\\nCatatan: widget Android standar tampil di layar utama. Kunci layar dan keamanan tetap memakai sistem Android.");
        instructions.setTextColor(0xFFB9C5D4);
        instructions.setTextSize(13);
        instructions.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams insLp = new LinearLayout.LayoutParams(-1, -2);
        insLp.topMargin = dp(22);
        page.addView(instructions, insLp);

        setContentView(page);
    }

    private void updateWidgets() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        ComponentName component = new ComponentName(this, GlassClockWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) GlassClockWidgetProvider.updateWidget(this, manager, id);
    }
}
