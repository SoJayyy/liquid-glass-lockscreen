plugins {
    id("com.android.application")
}

android {
    namespace = "com.walky.liquidglassclock"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.walky.liquidglassclock"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
