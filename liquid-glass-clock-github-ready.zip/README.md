# Liquid Glass Clock — Android

Widget jam digital bergaya Liquid Glass, format 24 jam. Proyek menggunakan Java + Android SDK tanpa library UI pihak ketiga agar build lebih sederhana.

## Fitur
- Widget jam digital besar (24 jam) yang diperbarui otomatis oleh Android `TextClock`.
- Hari dan tanggal mengikuti bahasa perangkat.
- Empat tema kaca: Silver, Champagne, Cool Blue, Rose Gold.
- Pratinjau dan petunjuk pemasangan widget di aplikasi.
- Tidak meminta PIN, sidik jari, aksesibilitas, atau izin sensitif.

## Memasang widget
1. Pasang APK.
2. Buka aplikasi Liquid Glass Clock.
3. Kembali ke layar utama.
4. Tekan lama area kosong > Widget > Liquid Glass Clock.
5. Tarik widget ke layar utama dan ubah ukurannya bila diperlukan.

## Batasan Android
Widget standar Android tampil di layar utama. Android 14/Realme UI tidak menyediakan API umum bagi aplikasi pihak ketiga untuk menaruh widget di lock screen. Kunci layar, PIN, dan sidik jari tetap dikelola sistem.

## Build lokal
Buka folder ini di Android Studio, lalu Build > Build Bundle(s) / APK(s) > Build APK(s).

## Build melalui GitHub Actions
Workflow `.github/workflows/build-apk.yml` akan membuat APK debug ketika didorong ke branch `main` atau dijalankan manual. Hasil tersedia sebagai artifact `LiquidGlassClock-debug-apk`.
