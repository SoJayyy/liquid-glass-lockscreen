package com.walky.ios27lockscreen

import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
             View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
             View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        setContent { LiquidGlassApp() }
    }
}

private data class GlassTheme(val name: String, val colors: List<Color>) {
    companion object {
        val presets = listOf(
            GlassTheme("Champagne", listOf(Color(0xFFFFF8ED), Color(0xFFD9C1A5), Color(0xFFB39A83))),
            GlassTheme("Silver", listOf(Color(0xFFFFFFFF), Color(0xFFD8DCE2), Color(0xFF9EA8B5))),
            GlassTheme("Cool blue", listOf(Color(0xFFF2FAFF), Color(0xFFB9D9EA), Color(0xFF8AAFC9))),
            GlassTheme("Rose gold", listOf(Color(0xFFFFF2EC), Color(0xFFE7BFB1), Color(0xFFB98779)))
        )
    }
}

@Composable
fun LiquidGlassApp() {
    val context = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    var torchOn by remember { mutableStateOf(false) }
    var use24 by remember { mutableStateOf(true) }
    var clockSize by remember { mutableFloatStateOf(150f) }
    var selectedTheme by remember { mutableIntStateOf(0) }
    var page by remember { mutableStateOf("preview") }
    var status by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) { now = Date(); delay(1000) }
    }

    val time = SimpleDateFormat(if (use24) "HH:mm" else "h:mm", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(now)
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("id", "ID")) else it.toString() }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF101014), surface = Color(0xFF202027),
        primary = Color(0xFFE5D3BD), onSurface = Color.White
    )) {
        if (page == "settings") {
            SettingsPage(
                use24 = use24, onUse24 = { use24 = it },
                clockSize = clockSize, onClockSize = { clockSize = it },
                selectedTheme = selectedTheme, onTheme = { selectedTheme = it },
                onBack = { page = "preview" },
                onApplyWallpaper = {
                    val result = applyLockWallpaper(context)
                    status = result
                }
            )
        } else {
            Box(Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(R.drawable.wallpaper_champagne),
                    contentDescription = "Wallpaper Liquid Glass",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(0x33251A14), Color(0x18000000), Color(0x6630394A)))
                ))
                Column(
                    modifier = Modifier.fillMaxSize().padding(top = 42.dp, bottom = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(date, color = Color.White.copy(alpha = .95f), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(18.dp))
                    LiquidClock(time, clockSize, GlassTheme.presets[selectedTheme])
                    Spacer(Modifier.weight(1f))
                    AnimatedVisibility(status.isNotBlank()) {
                        Text(status, color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 12.dp), textAlign = TextAlign.Center)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 48.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GlassButton(
                            icon = if (torchOn) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff,
                            label = "Senter",
                            onClick = {
                                torchOn = !torchOn
                                setTorch(context, torchOn) { status = it }
                            }
                        )
                        GlassButton(Icons.Filled.CameraAlt, "Kamera") {
                            try {
                                context.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (_: Exception) { status = "Aplikasi kamera tidak tersedia" }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { page = "settings" }) {
                            Icon(Icons.Filled.Settings, null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Pengaturan", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                        }
                        Text("Pratinjau · keamanan Android tetap aktif", color = Color.White.copy(alpha = .58f), fontSize = 9.sp)
                    }
                }
                Box(
                    Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                        .width(112.dp).height(34.dp).clip(CircleShape).background(Color.Black.copy(alpha = .96f))
                )
            }
        }
    }
}

@Composable
fun LiquidClock(time: String, size: Float, theme: GlassTheme) {
    val infinite = rememberInfiniteTransition(label = "glass")
    val shimmer by infinite.animateFloat(
        initialValue = .18f, targetValue = .65f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "shimmer"
    )
    Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
        Text(
            text = time, fontSize = size.sp, lineHeight = (size * 1.04f).sp,
            fontWeight = FontWeight.ExtraLight, letterSpacing = (-size * .055f).sp,
            textAlign = TextAlign.Center, color = theme.colors[1].copy(alpha = .25f),
            style = androidx.compose.ui.text.TextStyle(
                shadow = Shadow(Color.Black.copy(alpha = .6f), androidx.compose.ui.geometry.Offset(0f, 9f), 20f)
            )
        )
        Text(
            text = time, fontSize = size.sp, lineHeight = (size * 1.04f).sp,
            fontWeight = FontWeight.ExtraLight, letterSpacing = (-size * .055f).sp,
            textAlign = TextAlign.Center,
            style = androidx.compose.ui.text.TextStyle(
                brush = Brush.linearGradient(listOf(
                    theme.colors[0].copy(alpha = .98f),
                    theme.colors[1].copy(alpha = .72f + shimmer * .22f),
                    Color.White.copy(alpha = .98f),
                    theme.colors[2].copy(alpha = .86f)
                )),
                shadow = Shadow(Color.White.copy(alpha = .4f), androidx.compose.ui.geometry.Offset(-1f, -2f), 8f)
            )
        )
    }
}

@Composable
fun SettingsPage(
    use24: Boolean, onUse24: (Boolean) -> Unit,
    clockSize: Float, onClockSize: (Float) -> Unit,
    selectedTheme: Int, onTheme: (Int) -> Unit,
    onBack: () -> Unit, onApplyWallpaper: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().background(Color(0xFF101014)).statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Kembali", tint = Color.White) }
            Text("Personalisasi", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Text("Tampilan jam", color = Color(0xFFE5D3BD), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202027))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Ukuran angka", color = Color.White)
                        Slider(value = clockSize, onValueChange = onClockSize, valueRange = 105f..166f)
                        Text("${clockSize.toInt()} sp", color = Color.LightGray, fontSize = 12.sp)
                        HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Color.White.copy(alpha = .1f))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Format 24 jam", color = Color.White)
                                Text("Matikan untuk format 12 jam", color = Color.LightGray, fontSize = 11.sp)
                            }
                            Switch(checked = use24, onCheckedChange = onUse24)
                        }
                    }
                }
            }
            item {
                Text("Warna Liquid Glass", color = Color(0xFFE5D3BD), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202027))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        GlassTheme.presets.forEachIndexed { index, theme ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onTheme(index) }.padding(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(theme.colors)))
                                Spacer(Modifier.width(12.dp))
                                Text(theme.name, color = Color.White, modifier = Modifier.weight(1f))
                                if (selectedTheme == index) Icon(Icons.Filled.Check, null, tint = Color(0xFFE5D3BD))
                            }
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = onApplyWallpaper,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD8C3A9), contentColor = Color(0xFF211B17))
                ) {
                    Icon(Icons.Filled.Wallpaper, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Terapkan wallpaper layar kunci")
                }
                Text(
                    "Mengatur gambar wallpaper lock screen Android. Tampilan jam dan tombol pada aplikasi ini tetap berupa pratinjau, bukan pengganti Keyguard sistem.",
                    color = Color.LightGray, fontSize = 11.sp, lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
fun GlassButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick, modifier = Modifier.size(66.dp), shape = CircleShape,
        color = Color.White.copy(alpha = .13f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = .28f)),
        shadowElevation = 8.dp
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(27.dp))
        }
    }
}

fun applyLockWallpaper(context: Context): String {
    return try {
        val manager = WallpaperManager.getInstance(context)
        val bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.wallpaper_champagne)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
            "Wallpaper berhasil diterapkan ke layar kunci."
        } else {
            manager.setBitmap(bitmap)
            "Wallpaper diterapkan. Pemilihan layar kunci bergantung pada versi Android."
        }
    } catch (e: Exception) {
        "Gagal menerapkan wallpaper: periksa izin wallpaper perangkat."
    }
}

fun setTorch(context: Context, enabled: Boolean, onError: (String) -> Unit) {
    try {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id).get(
                android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE
            ) == true
        }
        if (cameraId == null) onError("Flash tidak tersedia")
        else manager.setTorchMode(cameraId, enabled)
    } catch (_: Exception) {
        onError("Tidak dapat mengaktifkan senter")
    }
}
