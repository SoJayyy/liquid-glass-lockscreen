# iOS 27 Liquid Glass Lock Screen — v2.0

Project Android Studio berbasis Kotlin + Jetpack Compose.

## Fitur versi 2.0
- Pratinjau layar penuh bergaya iPhone
- Jam real-time dan tanggal Bahasa Indonesia
- Efek tipografi Liquid Glass dengan shimmer
- Pilihan tema Champagne, Silver, Cool Blue, Rose Gold
- Pengaturan ukuran angka jam
- Format 12/24 jam
- Tombol senter dan kamera
- Menerapkan wallpaper gambar ke layar kunci Android melalui WallpaperManager
- PIN, pola, kata sandi, dan biometrik Android tidak disentuh

## Batasan Android
Aplikasi pihak ketiga tidak dapat mengganti Keyguard sistem sepenuhnya pada perangkat Android standar. Versi ini menerapkan wallpaper lock screen, sementara tampilan jam interaktif adalah pratinjau di dalam aplikasi. Keamanan Android tetap menjadi otoritas membuka perangkat.

## Build
1. Ekstrak ZIP.
2. Buka folder project di Android Studio.
3. Pastikan Android SDK Platform 35 terpasang.
4. Tunggu Gradle Sync, lalu tekan Run.
5. Untuk APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

Package: `com.walky.ios27lockscreen`
minSdk: 26 | targetSdk: 35
